<?php
$dataFile = 'data.json';

$data = json_decode(file_get_contents($dataFile), true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $jumlahResult = isset($_POST['jumlahResult']) ? (int)$_POST['jumlahResult'] : 1;

    $data[] = ['email' => $email, 'jumlahResult' => $jumlahResult];

    // Simpan data yang telah ditambahkan ke file JSON
    file_put_contents($dataFile, json_encode($data));

    echo json_encode(['success' => true, 'message' => 'Email Berhasil Ditambahkan.']);
} else {
    echo json_encode(['success' => false, 'message' => 'Gagal menambahkan email.']);
}
?>
