<?php
session_start();

$valid_username = 'SORK';
$valid_password = 'SORK';

if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']) {
    header('Location: atur.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if ($username === $valid_username && $password === $valid_password) {
        $_SESSION['logged_in'] = true;
        header('Location: atur.php');
        exit;
    } else {
        $error = "𝗟𝘂 𝗠𝗮𝘂 𝗡𝗴𝗮𝗽𝗮𝗶𝗻 𝗧𝗼𝗹𝗼𝗹.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <style>
        body {
            background-image: url('https://itzpire.com/file/b858daf35401.jpg'); /* Ganti dengan URL latar belakang anime Anda */
            background-size: cover;
            background-position: center;
            font-family: 'Roboto', sans-serif;
            color: #fff;
        }

        .card {
            margin-top: 50px;
            box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.5);
            background: rgba(0, 0, 0, 0.5); 
        }

        .card-body {
            padding: 2rem;
        }

        .form-group {
            position: relative;
            margin-bottom: 1rem;
        }

        .form-group label {
            position: absolute;
            top: 50%;
            left: 0.75rem;
            transform: translateY(-50%);
            font-size: 1.25rem;
            color: #3498db;
        }

        .form-group label i {
            margin-right: 0.5rem;
        }

        .form-control {
            padding: 1.5rem 2.5rem;
            background: rgba(255, 255, 255, 0.2); 
            color: #fff;
            border: 1px solid rgba(255, 255, 255, 0.3); 
            border-radius: 25px; 
            font-size: 1rem;
        }

        .form-control:focus {
            background: rgba(255, 255, 255, 0.3); 
            border-color: #3498db; 
        }

        .btn-login {
            background-color: #3498db;
            border: none;
            color: #fff;
            padding: 12px 20px;
            border-radius: 25px; 
            cursor: pointer;
            transition: background-color 0.3s ease;
            font-size: 1rem;
            text-transform: uppercase;
            font-weight: bold;
        }

        .btn-login:hover {
            background-color: #2980b9;
        }

        .error-message {
            color: #dc3545;
            margin-top: -10px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center align-items-center" style="height: 100vh;">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h2 class="text-center mb-4"><i class="fas fa-user"></i> Login</h2>
                        <?php if (isset($error)): ?>
                            <p class="error-message text-center"><?php echo $error; ?></p>
                        <?php endif; ?>
                        <form method="POST">
                            <div class="form-group">
                                <label for="username"><i class="fas fa-user"></i></label>
                                <input type="text" class="form-control" id="username" name="username" placeholder="Username" required>
                            </div>
                            <div class="form-group">
                                <label for="password"><i class="fas fa-lock"></i></label>
                                <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                            </div>
                            <button type="submit" class="btn btn-primary btn-block">Login</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</body>
</html>
