<?php 

$nik = "WEB || FORXZz HOST-25🐳";
$sender = "admin@SORK.id";
?>