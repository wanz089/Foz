<?php
$dataFile = 'data.json';

// Baca data dari file JSON
$data = json_decode(file_get_contents($dataFile), true);

// Hapus email yang telah kedaluwarsa
$currentTime = time();
$data = array_filter($data, function($emailData) use ($currentTime) {
    return ($currentTime - $emailData['timestamp']) <= $emailData['maxTime'];
});

// Simpan data yang telah difilter kembali ke file JSON
file_put_contents($dataFile, json_encode($data));

// Kembalikan data sebagai respons JSON
echo json_encode(array_values($data));
?>
